from django.shortcuts import render,redirect, HttpResponse

def index(request):
    return render(request, 'index.html')

def get_gold_farm(request):
    act = []
    if 'money' not in request.session:
        request.session['money'] = 0
    request.session['money'] += 50
    
    context = {
        'money': request.session['money'],
         
    }
    return render(request, 'index.html', context)

def reset(request):
    request.session.flush()
    return redirect('/')


